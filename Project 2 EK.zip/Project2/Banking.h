// this header file defines the Banking class, which is responsible for the calculations

 // Banking class declaration
class Banking {
public:
	void SetInitialInvestment(double t_initialInvestment); //sets the initial investment amount
	void SetMonthlyDeposit(double t_monthlyDeposit); // sets the mnothly deposit amount
	void SetInterestRate(double t_annualInterest); //sets annual interest rate
	void SetNumberOfYears(int t_numberOfYears); //sets number of years for calculations
	double GetInitialInvestment() const; // retrieves initial investment amount
	double GetMonthlyDeposit() const; //retrieves monthly deposit amount
	double GetInterestRate() const; //retrieves annual interest rate
	int GetNumberOfYears() const; //retrieves number of years
	//calculates and returns the balance without monthly deposits
	double calcBalanceWithoutMonthlyDeposit(double t_initialInvestment, double t_annualInterest, int t_numberOfYears);
	//calculates and returns the balance with monthly deposits
	double balanceWithMonthlyDeposit(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_numberOfYears);

private:
	double m_totalAmount; //stores total amount in investment amount
	double m_interestAmount; //sotres interest earned
	double m_yearlyTotalInterest; //stores total interest earned annually
	double m_monthlyDeposit; //stores monthly deposit amount
	double m_numberOfYears; //stores number of years for calculations
};


