// This program will take user input on investment amounts, monthly deposits, interest rates and amount of years of investment to produce and show the user two charts
// displaying information on the earned amount of interest and the balance of the account, both with and without additional monthly deposits.
// If the user enters invalid information after the prompt, they will be prompted to enter the correct information.
// Elizabeth Kharitonova
// Sep 10, 2023

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <stdexcept>
#include "Banking.h"

using namespace std;


// Declaring instance of banking class
Banking myInvestment;
double initialInvestment; // amount in dollars.
double monthlyDeposit; // in dollars
double annualInterest; // as a percentage.
double months;
int years;
char user_input = 'a';

// Function to print the home screen and get input from the user
// Prints the home screen and obtains user input for calculations.
void PrintHomeScreen();

// Function for validating integer input
// Returns the validated integer input
int validIntInput();

// Validates and retrieves double input from user
// Returns the validated double input
double validDoubleInput();



// main function
int main() {
	//main loop for user interaction
	while (user_input != 'q') {
		system("cls"); //clears screen
		PrintHomeScreen();

		// Calculate balance without monthly deposits
		myInvestment.calcBalanceWithoutMonthlyDeposit(myInvestment.GetInitialInvestment(), myInvestment.GetInterestRate(), myInvestment.GetNumberOfYears());
		// Calculate balance with monthly deposits
		myInvestment.balanceWithMonthlyDeposit(myInvestment.GetInitialInvestment(), myInvestment.GetMonthlyDeposit(), myInvestment.GetInterestRate(), myInvestment.GetNumberOfYears());

		cout << "Enter q to quit, or enter character/number to do another calculation. ";
		cin >> user_input;
	}

	return 0;
}

// Function to print the home screen and get input from the user
// prompts user to enter the initial investment amount, monthly deposit, annual interest and number of years
// if the inputs are below zero, an error message will be displayed and user will have to start process again.
void PrintHomeScreen() {
	try {
		cout << "Initial Investment Amount: $";
		initialInvestment = validDoubleInput();
		if (initialInvestment < 0) {
			throw runtime_error("Invalid entry.");
		}
		myInvestment.SetInitialInvestment(initialInvestment);
		cout << "Monthly Deposit: $";
		monthlyDeposit = validDoubleInput();
		if (monthlyDeposit < 0) {
			throw runtime_error("Invalid entry.");
		}
		myInvestment.SetMonthlyDeposit(monthlyDeposit);
		cout << "Annual Interest: %";
		annualInterest = validDoubleInput();;
		if (annualInterest < 0) {
			throw runtime_error("Invalid entry.");
		}
		myInvestment.SetInterestRate(annualInterest);
		cout << "Number of years: ";
		years = validIntInput();
		if (years <= 0) {
			throw runtime_error("Invalid entry.");
		}
		myInvestment.SetNumberOfYears(years);

		system("PAUSE"); //lets user take their time to read the output.
	}

	// displays error message when user entered a number below zero
	// puts user back into home screen
	catch (runtime_error& excpt) {
		cout << excpt.what() << endl;
		cout << "Enter positive value (0 or above)." << endl;
		system("PAUSE");
		system("cls");
		PrintHomeScreen();
	}
}

// Validates that input is integer
int validIntInput() {
	int x;

	while (1) {
		if (cin >> x) {
			// if integer, loop ends
			break;
		}
		else {
			// if not an integer, displays error message and loop continues
			cout << "Enter an integer.";
			cin.clear();
			while (cin.get() != '\n');
		}
	}

	return x;
}

// Validates that input is a double
double validDoubleInput() {
	double x;

	while (1) {
		if (cin >> x) {
			// if valid, loop ends
			break;
		}
		else {
			// if not a double, loop continues after showing error message
			cout << "Enter a number: ";
			cin.clear();
			while (cin.get() != '\n');
		}
	}

	return x;
}