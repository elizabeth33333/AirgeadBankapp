//this includes the functions for all calculations that will be used in the main function
//it includes methods for setting and getting financial parameters and for
//calculating and printing balance and interest information for investments with and without
//monthly deposits

#include "Banking.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Banking class
// Accessors and Mutators
void Banking::SetInitialInvestment(double t_initialInvestment) {
	// sets initial investment
	m_totalAmount = t_initialInvestment;
}
void Banking::SetMonthlyDeposit(double t_monthlyDeposit) {
	// sets monthly deposit
	m_monthlyDeposit = t_monthlyDeposit;
}
void Banking::SetInterestRate(double t_annualInterest) {
	// sets annual interest rate
	m_yearlyTotalInterest = t_annualInterest;
}
void Banking::SetNumberOfYears(int t_numberOfYears) {
	// sets the number of years
	m_numberOfYears = t_numberOfYears;
}
double Banking::GetInitialInvestment() const {
	//gets initial investment 
	return m_totalAmount;
}
double Banking::GetMonthlyDeposit() const {
	//gets th emonthly deposit
	return m_monthlyDeposit;
}
double Banking::GetInterestRate() const {
	//gets the interest rate
	return m_yearlyTotalInterest;
}
int Banking::GetNumberOfYears() const {
	//gets the number of years
	return m_numberOfYears;
}

// Calculates and prints balance without monthly deposit
double Banking::calcBalanceWithoutMonthlyDeposit(double t_initialInvestment, double t_annualInterest, int t_numberOfYears) {
	m_totalAmount = t_initialInvestment;

	// prints table headings/titles
	cout << endl << "      Balance and Interest Without Additional Monthly Deposits" << endl;
	cout << std::string(66, '=') << endl;
	cout << "Year           Year End Balance           Year End Earned Interest" << endl;
	cout << std::string(66, '-') << endl;

	// calculates yearly interest and year-end totals
	for (int i = 0; i < t_numberOfYears; i++) {
		//calculates interest earned for current year
		m_interestAmount = m_totalAmount * (t_annualInterest / 100);
		//updates total amount by adding interest earned
		m_totalAmount = m_totalAmount + m_interestAmount;
		//prints results for each year
		cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << m_totalAmount << "\t\t\t\t$" << m_interestAmount << endl;
	}

	return m_totalAmount;
}

// Calculates and prints balance with monthly deposit
double Banking::balanceWithMonthlyDeposit(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_numberOfYears) {
	m_totalAmount = t_initialInvestment;

	// prints table headings/titles
	cout << endl << "     Balance and Interest With Additional Monthly Deposits" << endl;
	cout << std::string(66, '=') << endl;
	cout << "Year          Year End Balance          Year End Earned Interest" << endl;
	cout << std::string(66, '-') << endl;

	// calculates yearly interest and year-end totals
	for (int i = 0; i < t_numberOfYears; i++) {
		m_yearlyTotalInterest = 0;

		for (int j = 0; j < 12; j++) {
			// calculates monthly interest
			m_interestAmount = (m_totalAmount + t_monthlyDeposit) * ((t_annualInterest / 100.00) / 12.00);
			m_yearlyTotalInterest = m_yearlyTotalInterest + m_interestAmount;
			m_totalAmount = m_totalAmount + t_monthlyDeposit + m_interestAmount;
		}

		//prints the results for each year (one line for each year)
		cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << m_totalAmount << "\t\t\t\t$" << m_yearlyTotalInterest << endl;
	}

	return m_totalAmount;
}